# Recalro — standalone product prototype

A mobile-first Recalro experience built from scratch using semantic HTML, CSS and vanilla JavaScript. The project includes a cinematic marketing landing page and an interactive learning workspace covering the 22 systems in the product brief.

## Run locally
No build step or package installation is required.
1. Unzip the folder.
2. Open `index.html` in a modern browser, or run a local static server:
   - `python -m http.server 8000`
   - Visit `http://localhost:8000`

## Brand system
- Teal: `#4A9E9E` (primary)
- Orange: `#E77D31` (secondary)
- Neutral backgrounds and surfaces
- Manrope headings, DM Sans interface text
- Official Recalro graduation-cap R artwork is in `assets/recalro-logo.png`.

The exact color values are sampled from the supplied brand reference image. If you have official brand hex values, update the CSS custom properties at the top of `styles.css`.

## Included experience
- Marketing homepage with autoplaying, muted, looping Pexels study footage in the hero.
- Responsive desktop/mobile navigation and workspace.
- Dashboard, subjects, roadmap, flashcards, memory center, knowledge vault, AI tutor, exam simulator, summaries, read-aloud, weakness detector, planner, readiness, quests, leaderboards, study groups, reward store, explain-it-to-me, weekly reports and settings.
- Working UI interactions: navigation, dark/light toggle, flashcard reveal and rating flow, knowledge search/filter, demo exam answer selection, browser speech synthesis, chat prototype, quest checkboxes and sample form flows.
- Local theme preference persistence.

## Video source
Hero footage: [Students Studying at the Library — Pexels](https://www.pexels.com/video/students-studying-at-the-library-9569684/), by Tima Miroshnichenko. The MP4 is loaded from Pexels' video CDN and requires an internet connection. If the CDN path changes, replace the `<source>` URL in `index.html` with the current download URL from the Pexels page.

## Important implementation boundary
This is a self-contained frontend prototype, not a connected production application. It does not include authentication, Supabase, FastAPI, database persistence, AI provider calls, server-side file processing, production SM-2 scheduling, or verified XP/gem transactions. UI examples and sample analytics are demonstration data. Do not present them as real user records.

Before production:
1. Connect authentication and account settings to the existing identity provider.
2. Map all existing routes, API contracts and database entities before replacing an existing app.
3. Connect subject/material uploads, AI extraction and generated content to backend APIs.
4. Wire flashcard ratings to the existing SM-2 implementation without changing its calculations.
5. Connect AI Tutor, summaries and explain-it-to-me to configured AI providers.
6. Verify exam question limits and pass threshold with the backend.
7. Persist roadmap, planner, knowledge vault, quests, groups and reward economy through approved backend work.
8. Add automated tests, accessibility audit and cross-device QA.

## Files
- `index.html` — marketing site and app shell
- `styles.css` — responsive design system and components
- `app.js` — navigation, demo data and interactions
- `assets/recalro-logo.png` — supplied logo artwork
